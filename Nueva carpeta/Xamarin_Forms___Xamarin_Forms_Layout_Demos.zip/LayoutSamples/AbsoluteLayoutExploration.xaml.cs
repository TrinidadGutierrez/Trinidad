﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace LayoutSamples
{
	public partial class AbsoluteLayoutExploration : ContentPage
	{
		public AbsoluteLayoutExploration ()
		{
			InitializeComponent ();
		}
	}
}

