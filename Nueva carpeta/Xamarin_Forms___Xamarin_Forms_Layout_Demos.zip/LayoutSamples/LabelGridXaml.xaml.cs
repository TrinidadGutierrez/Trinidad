﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace LayoutSamples
{
	public partial class LabelGridXaml : ContentPage
	{
		public LabelGridXaml ()
		{
			InitializeComponent ();
		}
	}
}

